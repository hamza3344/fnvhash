﻿using net.r_eg.algorithms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace hashmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string data = "Hello, World!"; // Data to be hashed
            MessageBox.Show(gethashfn1a64(data));
            MessageBox.Show(gethashfn1a128(data));
            

            
        }
        static string gethashfn1a64(string data)
        {
            return Fnv1a.GetHash64(data).ToString("x2");
        }
        static string gethashfn1a128(string data)
        {
            ulong high=Fnv1a.GetHash128LX4Cnh(data,out ulong low);
            return "high: "+high.ToString("x2")+" low: "+low.ToString("x2");
        }



    }
}
